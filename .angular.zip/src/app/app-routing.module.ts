import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TransactionsComponent } from './features/transactions/transactions.component';
import { PositionsComponent } from './features/positions/positions.component';

const routes: Routes = [
  { path: 'transactions', component: TransactionsComponent },
  { path: 'positions', component: PositionsComponent },
  { path: '**', redirectTo: 'transactions' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
