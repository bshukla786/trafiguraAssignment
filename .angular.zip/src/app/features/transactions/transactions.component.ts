import { Component } from '@angular/core';
import { TransactionService } from '../../core/services/transaction.service';
import { Transaction } from '../../core/models/transaction.model';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.scss']
})
export class TransactionsComponent {
  newTransaction: Transaction = {
    tradeID: 1,
    version: 1,
    securityCode: 'INF',
    quantity: 50,
    action: 'INSERT',
    buySell: 'Buy'
  };

  constructor(private transactionService: TransactionService) {}

  postTransaction() {
    this.transactionService.processTransaction(this.newTransaction)
      .subscribe({
        next: (response) => {
          console.log('Transaction processed successfully', response);
        },
        error: (error) => {
          console.error('Error processing transaction', error);
        }
      });
  }
}
