import { Component, OnInit } from '@angular/core';
import { PositionService } from '../../core/services/position.service';
import { Position } from '../../core/models/position.model';

@Component({
  selector: 'app-positions',
  templateUrl: './positions.component.html',
  styleUrls: ['./positions.component.scss']
})
export class PositionsComponent implements OnInit {
  positions: Position[] = [];
  displayedColumns: string[] = ['securityCode', 'quantity'];

  constructor(private positionService: PositionService) {}

  ngOnInit(): void {
    this.loadPositions();
  }

  loadPositions(): void {
    this.positionService.getPositions().subscribe({
      next: (data) => {
        this.positions = data;
        console.log('Positions fetched:', data);
      },
      error: (error) => {
        console.error('Error fetching positions:', error);
      }
    });
  }
}
