export interface Transaction {
  transactionID?: number;
  tradeID: number;
  version: number;
  securityCode: string;
  quantity: number;
  action: 'INSERT' | 'UPDATE' | 'CANCEL';
  buySell: 'Buy' | 'Sell';
}
