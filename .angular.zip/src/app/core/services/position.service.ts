import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Position } from '../models/position.model';

@Injectable({
  providedIn: 'root'
})
export class PositionService {
  private apiUrl = 'https://localhost:44339/api/positions';  // 👈 your GET endpoint

  constructor(private http: HttpClient) {}

  // GET: fetch current positions
  getPositions(): Observable<Position[]> {
    return this.http.get<Position[]>(this.apiUrl);
  }
}
