import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Transaction } from '../models/transaction.model';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private apiUrl = 'https://localhost:44339/api/Transactions';

  constructor(private http: HttpClient) {}

  // GET: fetch all transactions
  getTransactions(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(this.apiUrl);
  }

  // POST: process a new transaction
  processTransaction(transaction: Transaction): Observable<any> {
    return this.http.post(this.apiUrl, transaction);
  }
}
