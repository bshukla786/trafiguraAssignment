﻿using System.Text.Json;
using EquityPositionManager.Models;

namespace EquityPositionManager.Repositories;

public class PositionRepository : IPositionRepository
{
    private readonly string _filePath = "Data/positions.json";

    public async Task<List<Position>> GetAllAsync()
    {
        if (!File.Exists(_filePath))
            return new List<Position>();

        var json = await File.ReadAllTextAsync(_filePath);
        return JsonSerializer.Deserialize<List<Position>>(json)
               ?? new List<Position>();
    }

    public async Task<Position?> GetBySecurityAsync(string securityCode)
    {
        var positions = await GetAllAsync();
        return positions.FirstOrDefault(p => p.SecurityCode == securityCode);
    }

    public async Task UpsertAsync(Position pos)
    {
        var positions = await GetAllAsync();
        var existing = positions.FirstOrDefault(p => p.SecurityCode == pos.SecurityCode);
        if (existing == null)
            positions.Add(pos);
        else
            existing.Quantity = pos.Quantity;

        await SaveAllAsync(positions);
    }

    public async Task RemoveAsync(string securityCode)
    {
        var positions = await GetAllAsync();
        positions.RemoveAll(p => p.SecurityCode == securityCode);
        await SaveAllAsync(positions);
    }

    private async Task SaveAllAsync(List<Position> positions)
    {
        var json = JsonSerializer.Serialize(positions, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(_filePath, json);
    }
}
