﻿using System.Text.Json;
using EquityPositionManager.Models;

namespace EquityPositionManager.Repositories;

public class TransactionRepository : ITransactionRepository
{
    private readonly string _filePath = "Data/transactions.json";

    public async Task<List<TradeTransaction>> GetAllAsync()
    {
        if (!File.Exists(_filePath))
            return new List<TradeTransaction>();

        var json = await File.ReadAllTextAsync(_filePath);
        return JsonSerializer.Deserialize<List<TradeTransaction>>(json)
               ?? new List<TradeTransaction>();
    }

    public async Task AddAsync(TradeTransaction txn)
    {
        var txns = await GetAllAsync();
        txn.TransactionId = txns.Any() ? txns.Max(t => t.TransactionId) + 1 : 1;
        txns.Add(txn);
        await SaveAllAsync(txns);
    }

    public async Task<TradeTransaction?> GetLatestByTradeIdAsync(int tradeId)
    {
        var txns = await GetAllAsync();
        return txns.Where(t => t.TradeId == tradeId)
                   .OrderByDescending(t => t.Version)
                   .FirstOrDefault();
    }

    private async Task SaveAllAsync(List<TradeTransaction> txns)
    {
        var json = JsonSerializer.Serialize(txns, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(_filePath, json);
    }
}
