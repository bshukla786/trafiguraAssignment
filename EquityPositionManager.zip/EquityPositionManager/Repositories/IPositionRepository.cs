﻿using EquityPositionManager.Models;

namespace EquityPositionManager.Repositories;

public interface IPositionRepository
{
    Task<List<Position>> GetAllAsync();
    Task<Position?> GetBySecurityAsync(string securityCode);
    Task UpsertAsync(Position position);
    Task RemoveAsync(string securityCode);
}
