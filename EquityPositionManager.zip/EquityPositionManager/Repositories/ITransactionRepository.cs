﻿using EquityPositionManager.Models;

namespace EquityPositionManager.Repositories;

public interface ITransactionRepository
{
    Task<List<TradeTransaction>> GetAllAsync();
    Task AddAsync(TradeTransaction txn);
    Task<TradeTransaction?> GetLatestByTradeIdAsync(int tradeId);
}
