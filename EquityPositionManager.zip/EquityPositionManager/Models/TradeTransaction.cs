﻿namespace EquityPositionManager.Models;

public class TradeTransaction
{
    public int TransactionId { get; set; }
    public int TradeId { get; set; }
    public int Version { get; set; }
    public string SecurityCode { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public string Action { get; set; } = string.Empty;  // "INSERT", "UPDATE", "CANCEL"
    public string BuySell { get; set; } = string.Empty; // "Buy", "Sell"
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
