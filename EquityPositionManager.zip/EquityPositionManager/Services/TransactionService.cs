﻿using EquityPositionManager.Models;
using EquityPositionManager.Repositories;

namespace EquityPositionManager.Services;

public class TransactionService
{
    private readonly ITransactionRepository _txnRepo;
    private readonly IPositionRepository _posRepo;

    public TransactionService(ITransactionRepository txnRepo, IPositionRepository posRepo)
    {
        _txnRepo = txnRepo;
        _posRepo = posRepo;
    }

    public async Task ProcessTransactionAsync(TradeTransaction txn)
    {
        var latestTxn = await _txnRepo.GetLatestByTradeIdAsync(txn.TradeId);
        if (latestTxn != null && txn.Version <= latestTxn.Version)
            return;

        if (latestTxn != null)
            await AdjustPositionAsync(latestTxn, revert: true);

        if (txn.Action != "CANCEL")
            await AdjustPositionAsync(txn, revert: false);

        await _txnRepo.AddAsync(txn);
    }

    public async Task<List<Position>> GetPositionsAsync()
    {
        return await _posRepo.GetAllAsync();
    }

    private async Task AdjustPositionAsync(TradeTransaction txn, bool revert)
    {
        int sign = (txn.BuySell == "Buy" ? 1 : -1) * (revert ? -1 : 1);
        var pos = await _posRepo.GetBySecurityAsync(txn.SecurityCode) ?? new Position { SecurityCode = txn.SecurityCode };
        pos.Quantity += sign * txn.Quantity;

        if (pos.Quantity == 0)
            await _posRepo.RemoveAsync(pos.SecurityCode);
        else
            await _posRepo.UpsertAsync(pos);
    }
}
