﻿using Microsoft.AspNetCore.Mvc;
using EquityPositionManager.Models;
using EquityPositionManager.Services;

namespace EquityPositionManager.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TransactionsController : ControllerBase
{
    private readonly TransactionService _service;

    public TransactionsController(TransactionService service)
    {
        _service = service;
    }

    [HttpPost]
    public async Task<IActionResult> PostTransaction(TradeTransaction txn)
    {
        await _service.ProcessTransactionAsync(txn);
        return Ok();
    }

    [HttpGet("/api/positions")]
    public async Task<IActionResult> GetPositions()
    {
        var positions = await _service.GetPositionsAsync();
        return Ok(positions);
    }
}
