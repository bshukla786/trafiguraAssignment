using Xunit;
using Moq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using EquityPositionManager.Services;
using EquityPositionManager.Models;
using EquityPositionManager.Repositories;
using FluentAssertions;

namespace EquityPositionManager.Tests
{
    public class TransactionServiceTests
    {
        private readonly Mock<ITransactionRepository> _transactionRepoMock;
        private readonly Mock<IPositionRepository> _positionRepoMock;
        private readonly TransactionService _service;

        public TransactionServiceTests()
        {
            _transactionRepoMock = new Mock<ITransactionRepository>();
            _positionRepoMock = new Mock<IPositionRepository>();

            _service = new TransactionService(_transactionRepoMock.Object, _positionRepoMock.Object);
        }

        [Fact]
        public async Task ProcessTransaction_InsertBuy_AddsPositionCorrectly()
        {
            // Arrange
            var transaction = new TradeTransaction
            {
                TradeId = 1,
                Version = 1,
                SecurityCode = "REL",
                Quantity = 100,
                Action = "INSERT",
                BuySell = "Buy"
            };

            _transactionRepoMock.Setup(r => r.GetLatestByTradeIdAsync(1))
                .ReturnsAsync((TradeTransaction)null);

            _transactionRepoMock.Setup(r => r.AddAsync(transaction))
                .Returns(Task.CompletedTask);

            _positionRepoMock.Setup(r => r.GetBySecurityAsync("REL"))
                .ReturnsAsync((Position)null);

            _positionRepoMock.Setup(r => r.UpsertAsync(It.IsAny<Position>()))
                .Returns(Task.CompletedTask);

            // Act
            await _service.ProcessTransactionAsync(transaction);

            // Assert
            _positionRepoMock.Verify(r => r.UpsertAsync(It.Is<Position>(
                p => p.SecurityCode == "REL" && p.Quantity == 100
            )), Times.Once);
        }

        [Fact]
        public async Task ProcessTransaction_UpdateBuy_RevertsPreviousAndAddsNew()
        {
            // Arrange
            var previousTransaction = new TradeTransaction
            {
                TradeId = 1,
                Version = 1,
                SecurityCode = "REL",
                Quantity = 100,
                Action = "INSERT",
                BuySell = "Buy"
            };

            var transaction = new TradeTransaction
            {
                TradeId = 1,
                Version = 2,
                SecurityCode = "REL",
                Quantity = 150,
                Action = "UPDATE",
                BuySell = "Buy"
            };

            _transactionRepoMock.Setup(r => r.GetLatestByTradeIdAsync(1))
                .ReturnsAsync(previousTransaction);

            _transactionRepoMock.Setup(r => r.AddAsync(transaction))
                .Returns(Task.CompletedTask);

            _positionRepoMock.Setup(r => r.GetBySecurityAsync("REL"))
                .ReturnsAsync(new Position { SecurityCode = "REL", Quantity = 100 });

            _positionRepoMock.Setup(r => r.UpsertAsync(It.IsAny<Position>()))
                .Returns(Task.CompletedTask);

            // Act
            await _service.ProcessTransactionAsync(transaction);

            // Assert
            _positionRepoMock.Verify(r => r.UpsertAsync(It.Is<Position>(
                p => p.SecurityCode == "REL" && p.Quantity == 150
            )), Times.Once);
        }

        [Fact]
        public async Task ProcessTransaction_Cancel_RevertsPreviousAndRemovesPositionIfZero()
        {
            // Arrange
            var previousTransaction = new TradeTransaction
            {
                TradeId = 1,
                Version = 2,
                SecurityCode = "REL",
                Quantity = 150,
                Action = "UPDATE",
                BuySell = "Buy"
            };

            var cancelTransaction = new TradeTransaction
            {
                TradeId = 1,
                Version = 3,
                SecurityCode = "REL",
                Quantity = 999, // irrelevant
                Action = "CANCEL",
                BuySell = "Sell" // irrelevant
            };

            _transactionRepoMock.Setup(r => r.GetLatestByTradeIdAsync(1))
                .ReturnsAsync(previousTransaction);

            _transactionRepoMock.Setup(r => r.AddAsync(cancelTransaction))
                .Returns(Task.CompletedTask);

            _positionRepoMock.Setup(r => r.GetBySecurityAsync("REL"))
                .ReturnsAsync(new Position { SecurityCode = "REL", Quantity = 150 });

            _positionRepoMock.Setup(r => r.RemoveAsync("REL"))
                .Returns(Task.CompletedTask);

            // Act
            await _service.ProcessTransactionAsync(cancelTransaction);

            // Assert
            _transactionRepoMock.Verify(r => r.AddAsync(cancelTransaction), Times.Once);

            _positionRepoMock.Verify(r => r.RemoveAsync("REL"), Times.Once);
        }


        [Fact]
        public async Task ProcessTransaction_LowerVersion_Ignored()
        {
            // Arrange
            var latestTransaction = new TradeTransaction
            {
                TradeId = 1,
                Version = 2,
                SecurityCode = "REL",
                Quantity = 150,
                Action = "UPDATE",
                BuySell = "Buy"
            };

            var oldTransaction = new TradeTransaction
            {
                TradeId = 1,
                Version = 1,
                SecurityCode = "REL",
                Quantity = 100,
                Action = "INSERT",
                BuySell = "Buy"
            };

            _transactionRepoMock.Setup(r => r.GetLatestByTradeIdAsync(1))
                .ReturnsAsync(latestTransaction);

            // Act
            await _service.ProcessTransactionAsync(oldTransaction);

            // Assert
            _positionRepoMock.Verify(r => r.UpsertAsync(It.IsAny<Position>()), Times.Never);
        }
    }
}
